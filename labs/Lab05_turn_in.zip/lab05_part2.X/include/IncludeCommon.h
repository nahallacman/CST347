/* 
 * File:   IncludeCommon.h
 * Author: mainuser
 *
 * Created on May 21, 2015, 5:06 PM
 */

#ifndef INCLUDECOMMON_H
#define	INCLUDECOMMON_H

#ifdef	__cplusplus
extern "C" {
#endif

#define CALS_BOARD


#ifdef	__cplusplus
}
#endif

#endif	/* INCLUDECOMMON_H */

