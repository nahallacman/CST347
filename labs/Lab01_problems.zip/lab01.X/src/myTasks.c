#include "myTasks.h"
//static void taskToggleAnLED(void *pvParameters)

/*
static void taskmyLeds(void *pvParameters)
//void myLedsTask(uint8_t time, uint8_t tasktype)
{
    toggleLED(1);

}
*/


