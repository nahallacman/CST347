#include "uartdrv.h"

void __attribute__((interrupt(ipl0), vector(_UART1_VECTOR))) vUART1_ISR_Wrapper(void);

void initUart(UART_MODULE umPortNum, uint32_t ui32WantedBaud)
{
    /* Variables */

    /* UART Configuration */
    UARTConfigure(umPortNum, UART_ENABLE_PINS_TX_RX_ONLY);

    /* UART FIFO Mode */
    UARTSetFifoMode(umPortNum, UART_INTERRUPT_ON_TX_NOT_FULL |
                               UART_INTERRUPT_ON_RX_NOT_EMPTY);

    /* UART Line Control */
    UARTSetLineControl(umPortNum, UART_DATA_SIZE_8_BITS | 
                                  UART_PARITY_NONE |
                                  UART_STOP_BITS_1);

    /* Set the Baud Rate of the UART */
    UARTSetDataRate(umPortNum,
            (uint32_t)configPERIPHERAL_CLOCK_HZ, ui32WantedBaud);

    /* Enable the UART for Transmit Only*/
    UARTEnable(umPortNum, UART_ENABLE_FLAGS(UART_PERIPHERAL |
                                            UART_TX |
                                            UART_RX));

    /* Set UART INterrupt Vector Priority*/
    INTSetVectorPriority(INT_VECTOR_UART(UART1), INT_PRIORITY_LEVEL_2);

    /* Enable RX INterrupt */
    INTEnable(INT_SOURCE_UART_RX(umPortNum), INT_ENABLED);
    /* INTEnable(INT_SOURCE_UART_TX(umPortNum), INT_ENABLED); */ /* Only do this when ready to transmit */
}


void vUART1_ISR(void)
{
    /* Variables */
    static portBASE_TYPE xHigherPriorityTaskWoken;

    // YOUR RX AND TX operations go HERE. When the ISR runs, you will need to
    // detect if the RX or TX flag caused the interrupt. Priority should be given
    // to the RX interrupt. That is, the RX operation code should be run and the
    // ISR exited. Then the CPU will be interrupt again from the currently
    // pending TX interrupt that did not get handle the last time. The interrupt
    // flags can be checked using the plib.

    xHigherPriorityTaskWoken = xTaskResumeFromISR(yourRxTask);


    /* If sending or receiving necessitates a context switch, then switch now. */
    portEND_SWITCHING_ISR( xHigherPriorityTaskWoken );
}

