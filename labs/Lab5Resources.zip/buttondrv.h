#ifndef BUTTONDRV_H
#define	BUTTONDRV_H

#include <FreeRTOS.h>

// Prototypes
void initCN(void);

#endif	/* BUTTONDRV_H */

